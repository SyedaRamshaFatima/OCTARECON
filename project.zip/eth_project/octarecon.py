import subprocess  # for nslookup, whois
import re  # for nslookup
import requests  # for geoip, ipnetblock, subdomain, emails
import json  # for detectcms
from datetime import datetime  # for timing
import sys  # for file logging

# Importing your custom tools
from tools.detectcms import get_cms
from tools.nslookup import get_ip_from_domain
from tools.geoip import get_ip_location
from tools.ipnetblock import get_ip_netblock
from tools.subdomain import get_subdomains
from tools.whois import get_whois
from tools.sslinfo import get_ssl_info
from tools.emails import get_emails

# Define a dictionary with options using the first letter of each tool
options = {
    "I": ("IP Lookup", lambda domain: get_ip_from_domain(domain, "I")),
    "G": ("GeoIP", lambda ip: get_ip_location(ip)),
    "N": ("IP Netblock", lambda ip: get_ip_netblock(ip)),
    "C": ("CMS Detection", lambda domain: get_cms(domain)),
    "S": ("Subdomain Enumeration", lambda domain: get_subdomains(domain)),
    "W": ("Whois Lookup", lambda domain: get_whois(domain)),
    "L": ("SSL Info", lambda domain: get_ssl_info(domain)),
    "E": ("Email Harvesting", lambda domain: get_emails(domain)),
    "A": ("Run All", None)  # Special option to run all tools
}

# OCTARECON ASCII Art
octarecon_text = """
           
           
               OOO   CCCCC  TTTTTTT  AAAAA   RRRR    EEEEE  CCCCC   OOO   N   N
              O   O  C        T      A   A   R   R   E      C      O   O  NN  N
              O   O  C        T      AAAAA   RRRR    EEEE   C      O   O  N N N
              O   O  C        T      A   A   R  R    E      C      O   O  N  NN
               OOO   CCCCC    T      A   A   R   R   EEEEE  CCCCC   OOO   N   N
               
       --------------------------  This is OCTARECON  ----------------------------
                    
                       
                       PRESENTED BY 22K4792, 22K4711 AND 22K4676 
                       
                        
"""

# Function to print the OCTARECON design
def print_octarecon():
    print(octarecon_text.center(80))

class Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for stream in self.streams:
            stream.write(data)
            stream.flush()

    def flush(self):
        for stream in self.streams:
            try:
                stream.flush()
            except ValueError:
                # Stream is already closed
                pass



def main():

    # Display the OCTARECON ASCII design
    print_octarecon()

    domain = input("Input the domain: ")

    print("\nSelect one or more options to run (e.g., I G W):")
    for key, (name, _) in options.items():
        print(f"{key} - {name}")
    
    choices = input("\nEnter your choices (letters): ").upper().replace(",", " ").split()

    start_time = datetime.now()  # Record the start time

    # Open file to write results
    with open("finalresult.txt", "a") as file:  # Append to avoid overwriting previous results
        # Redirect stdout to both console and file
        original_stdout = sys.stdout
        sys.stdout = Tee(sys.stdout, file)

        # Label the new data block
        file.write(f"\n\n\n\n=====================================================================               DATA                =====================================================================\n\n\n")

        ip = None  # Initialize IP variable
        section_counter = 1  # Initialize section counter for tools

        if "A" in choices:  # Run all tools if 'A' is selected
            print("\nRunning all tools...\n")
            ip = get_ip_from_domain(domain, "A")  # Only resolve IP once if needed
            for key, (_, func) in options.items():
                if func:  # Skip the "Run All" entry itself
                    print(f"\n{section_counter}. Running {options[key][0]}...\n")
                    if key in ["G", "N"]:  # IP-based functions
                        func(ip)
                    else:
                        func(domain)
                    section_counter += 1  # Increment counter
        else:
            for choice in choices:
                if choice in options:
                    print(f"\n{section_counter}. Running {options[choice][0]}...\n")
                    _, func = options[choice]
                    if choice == "I":  # IP Lookup selected
                        ip = get_ip_from_domain(domain, "I")
                        print(f"IP Address: {ip}")
                    elif choice in ["G", "N"]:  # IP-based functions
                        if not ip:  # Resolve IP only if not already resolved
                            ip = get_ip_from_domain(domain, "G")
                        func(ip)
                    else:
                        func(domain)
                    section_counter += 1  # Increment counter
                else:
                    print(f"Invalid choice: {choice}")

        end_time = datetime.now()  # Record the end time
        execution_time = end_time - start_time  # Calculate the execution time
        print(f"\nTIME TAKEN: {execution_time}")

        # Restore original stdout before closing the file
        sys.stdout = original_stdout

if __name__ == "__main__":
    main()
